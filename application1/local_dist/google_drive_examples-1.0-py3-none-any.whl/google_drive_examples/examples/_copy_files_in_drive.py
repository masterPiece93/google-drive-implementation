
def main():
    raise NotImplementedError(NotImplementedError.__doc__)
